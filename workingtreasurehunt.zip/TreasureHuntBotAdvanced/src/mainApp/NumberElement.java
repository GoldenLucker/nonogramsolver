package mainApp;

public class NumberElement {
	
	
	    public int xPosOnScreen;
	    public int yPosOnScreen;
	    public int number;
	    public int yPosInNumberHint;
	    public int xPosInNumberHint;
	    public boolean assigned;
	    
	    public NumberElement(int x, int y, int number) {
	        this.xPosOnScreen = x;
	        this.yPosOnScreen = y;
	        this.number = number;
	    }

	    public int getNumber() {
			return number;
		}

		public void setNumber(int number) {
			this.number = number;
		}

		public int getyPosInNumberHint() {
			return yPosInNumberHint;
		}

		public void setyPosInNumberHint(int yPosInNumberHint) {
			this.yPosInNumberHint = yPosInNumberHint;
		}

		public int getxPosInNumberHint() {
			return xPosInNumberHint;
		}

		public void setxPosInNumberHint(int xPosInNumberHint) {
			this.xPosInNumberHint = xPosInNumberHint;
		}

		
	    
	    public String toString(){
	    	return "Number: "+number+" X/Y "+xPosOnScreen+"/"+yPosOnScreen;
	    }
	

}
