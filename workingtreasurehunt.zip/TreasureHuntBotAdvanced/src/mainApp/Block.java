package mainApp;

import java.util.ArrayList;
import java.util.Random;

public class Block {

	private boolean unknownBox;
	private boolean bombBox=false;
	private boolean freeBox=false;
	private boolean clickedBox=false;
	private boolean defCorrectNumberOfFreeBlocks=false;
	private boolean VerticalStreakTested=false;
	private boolean horizontalStreakConfirmed=false;
	private boolean verticalStreakConfirmed=false;
	private boolean HorizontalStreakTested=false;
	private boolean fullyCorrectBox=false;
	static int totalBoxes=0;
	//int[] Position = new int[2];
	private int xPositionCoordinates;
	private int yPositionCoordinates;
	int xPosition;
	int yPosition;
	
	Random rng;
//	private ArrayList allBlocks;
		public Block(int xPosition,int yPosition) {
			this.yPosition= yPosition;
			this.xPosition= xPosition;
			
			this.unknownBox = true;
			this.clickedBox=false;
			totalBoxes++;
//			this.Position[0]= xPosition ;
//			this.Position[1]= yPosition ;
			rng = new Random();
		}
		
	
	 
	 public int getxPositionCoordinates() {
		return xPositionCoordinates;
	}

	public void setxPositionCoordinates(int xPositionCoordinates) {
		this.xPositionCoordinates = xPositionCoordinates;
	}

	public int getyPositionCoordinates() {
		return yPositionCoordinates;
	}

	public void setyPositionCoordinates(int yPositionCoordinates) {
		this.yPositionCoordinates = yPositionCoordinates;
	}
	
	
	
	
	public void setDefCorrectAmountOfBoxes(boolean bool) {
		if(!this.defCorrectNumberOfFreeBlocks)
		this.defCorrectNumberOfFreeBlocks = bool;
		this.unknownBox =false;
	}
	public boolean isDefCorrectNumberOfBoxes() {
		return this.defCorrectNumberOfFreeBlocks;
	}
	public boolean isHorizontalStreakConfirmed() {
		return this.horizontalStreakConfirmed;
	}
	public boolean isVerticalStreakConfirmed() {
		return this.verticalStreakConfirmed;
	}
	public void setHorizontalStreakConfirmed(boolean bool) {
		this.horizontalStreakConfirmed=bool;
	}
	public void setVerticalStreakConfirmed(boolean bool) {
		this.verticalStreakConfirmed=bool;
	}
	
	public boolean isUnknownBox() {
		return unknownBox;
	}
	public boolean isBombBox() {
		return bombBox;
	}
	public boolean isFreeBox() {
		return freeBox;
	}
	public boolean isClickedBox() {
		return clickedBox;
	}
	
	public int getXPosition(){
		return xPosition;
	}
	public int getYPosition() {
		return yPosition;
	}
//	public int[] getPosition() {
//		return this.Position;
//	}
	public String toString() {
		return "Position X/Y: "+ xPosition +"/"+ yPosition+ "isUnknown: "+isUnknownBox()+" isFree: "+isFreeBox()+"\t Locked?: "+fullyCorrectBox+"XCord/YCord: "+
				getxPositionCoordinates()+"/"+getyPositionCoordinates()+"\n";
	}
	public void setBombBox(boolean isBomb) {
		if(!this.fullyCorrectBox) {
		this.bombBox = isBomb;
		this.freeBox = false;
		this.unknownBox = false;
		}
	}
	public void setClickedBox(boolean isClicked) {
		this.clickedBox = isClicked;
	}
	public void setUnknownBox(boolean isUnknown) {
		if(!this.fullyCorrectBox) {
		this.unknownBox = isUnknown;
		this.freeBox = false;
		this.bombBox = false;
		this.defCorrectNumberOfFreeBlocks= false;
		}
	}
	public void setFreeBox(boolean isFree) {
		if(!this.fullyCorrectBox) {
		this.freeBox = isFree;
		this.unknownBox = false;
		this.bombBox = false;
		}
	}
	// Zwischen freeBox und BombBox
	public boolean assignRandomBombBox() {
		boolean random = rng.nextBoolean();
		
		
		if (!this.fullyCorrectBox && !isLineFullOfFreeBlocks()) {
			this.setBombBox(random);
		}
		if(!this.fullyCorrectBox&& random==false) {
			this.setFreeBox(true);
		}
		return random;
	}
	
	private boolean isLineFullOfFreeBlocks() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isFullyCorrectBox() {
		return this.fullyCorrectBox;
	}
	public void setFullyCorrectBox(boolean bool) {
		this.fullyCorrectBox= bool;
		this.unknownBox=!bool;
	}
	public void setVerticalStreakTested(boolean bool) {
		VerticalStreakTested= bool;
	}
	public void setHorizontalStreakTested(boolean bool) {
		HorizontalStreakTested= bool;
	}
	public boolean isVerticalStreakTested() {
		return VerticalStreakTested;
	}
	public boolean isHorizontalStreakTested() {
		return HorizontalStreakTested;
	}
	 public Block copy() {
	        Block copiedBlock = new Block(this.xPosition, this.yPosition);
	        // Kopiere die Zustände der Instanzvariablen
	        copiedBlock.fullyCorrectBox  = this.fullyCorrectBox;
	        copiedBlock.unknownBox = this.unknownBox;
	        copiedBlock.bombBox = this.bombBox;
	        copiedBlock.freeBox = this.freeBox;
	        copiedBlock.clickedBox = this.clickedBox;
	        copiedBlock.defCorrectNumberOfFreeBlocks = this.defCorrectNumberOfFreeBlocks;
	        copiedBlock.VerticalStreakTested = this.VerticalStreakTested;
	        copiedBlock.HorizontalStreakTested = this.HorizontalStreakTested;
	        copiedBlock.horizontalStreakConfirmed = this.horizontalStreakConfirmed;
	        copiedBlock.verticalStreakConfirmed = this.verticalStreakConfirmed;
	        copiedBlock.xPositionCoordinates = this.xPositionCoordinates;
	        copiedBlock.yPositionCoordinates = this.yPositionCoordinates;
	        // rng wird nicht kopiert, da es ein gemeinsames Random-Objekt sein kann.
	        // totalBoxes wird nicht erhöht, da es die Gesamtzahl der erstellten Instanzen zählt,
	        // und die Kopie zählt hier nicht als neue Instanz im Kontext dieses Zählers.

	        return copiedBlock;
	    }

	
	 public int getHorizontalNumberIndex(ArrayList<NumberHint> numberHints) {
		for (int i=0;i<numberHints.size();i++) {
			if (numberHints.get(i).getYPosition()== this.yPosition) {
				return i;
			}
		}
		return -1;
		
	}
	 public int getVerticalNumberIndex(ArrayList<NumberHint> numberHints) {
			for (int i=0;i<numberHints.size();i++) {
				if (numberHints.get(i).getXPosition()== this.xPosition) {
					return i;
				}
			}
			return -1;
			
		}
	
	
	
	
}
