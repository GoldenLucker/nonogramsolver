package mainApp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class PlayingField {
	private Scanner scan1 = new Scanner(System.in);
	private ArrayList<Block> allBlocks = new ArrayList<Block>();
//  private ArrayList<NumberHint> numberHintsX = new ArrayList<NumberHint>();
//	private ArrayList<NumberHint> numberHintsY = new ArrayList<NumberHint>();
	private ArrayList<NumberHint> numberHints = new ArrayList<NumberHint>();
	private int fieldSize;
	private PlayingField playingFieldSaveState;
	
	public PlayingField(int fieldSize) {
		this.fieldSize= fieldSize;
		generateBlocks();
		generateEmptyNumberHints();
	}

	private void generateEmptyNumberHints() {
		
		for(int i=1;i<=fieldSize;i++) {
			numberHints.add(new NumberHint(i,0));
			numberHints.add(new NumberHint(0,i));
			}
		}
		
	

	private void generateBlocks() {
		int totalBlocks =this.fieldSize*this.fieldSize;
		
		for (int i=1;i<=fieldSize;i++) {
			for(int o=1; o<=this.fieldSize;o++) {
				allBlocks.add(new Block(i, o));
			}
		}
	}
	
	
	public boolean testFieldForRightAmountOfBoxesPerLine() {
		resetAmountOfFreeBoxes();
		//checkIfBoxFullyConfirmedXandYHint();
		for (int i=0;i<this.getNumberHints().size();i++) {
			this.numberHints.get(i).amountOfFreeBoxes(this.getAllBlocks());
			if(this.getNumberHints().get(i).getAmountOfFreeBoxes()== this.getNumberHints().get(i).getAddedNumbers()) {
				this.getNumberHints().get(i).setCorrectNumberOfBoxesInLine(true);
			}
			else
				this.getNumberHints().get(i).setCorrectNumberOfBoxesInLine(false);
		}
		for (int i=0;i<this.getNumberHints().size();i++) {
			if (this.getNumberHints().get(i).isCorrectNumberOfBoxes()==false) {
				confirmCorrectAmountOfBoxes();
				return false;
			}
		}
		confirmCorrectAmountOfBoxes();
		return true;
		}
	
	
	
	
	
	private void resetAmountOfFreeBoxes() {
		for (int i=0;i<this.getNumberHints().size();i++) {
			this.getNumberHints().get(i).resetAmountOfFreeBoxes();
		}
		
	}

		//Nach playingField.testField(); ausführen um "Korrekte anzahl an Freien Feldern" auf alle Boxen zu Locken.
		public void confirmCorrectAmountOfBoxes() {
			for(int i=0;i<this.getAllBlocks().size();i++) {
				for(int j=0;j<this.getNumberHints().size();j++) {
			if( this.getNumberHints().get(j).isInLine(this.getAllBlocks().get(i))&& this.getNumberHints().get(j).isCorrectNumberOfBoxes()) {
				this.getAllBlocks().get(i).setDefCorrectAmountOfBoxes(true);
			}
			}
		}
		}
		
	

	public void getAllUnknownAndFreeBlocksInRow() {
	//	if(g)
		
	}
	
	public ArrayList<Block> getAllBlocks() {
		return this.allBlocks;
	}
	public ArrayList<NumberHint> getNumberHintsX(){
		return this.numberHints;
	}
	public ArrayList<NumberHint> getNumberHintsY(){
		return this.numberHints;
	}
	public ArrayList<NumberHint> getNumberHints(){
		return this.numberHints;
	}
	public int getFieldSize() {
		return this.fieldSize;
	}

	public void bruteForce(int tries) {
//		this.playingFieldSaveState = playingFieldSaveState;
		
		int counterRightHints=0;
		int counterRightAmountOfBoxes=0;
		int counterFullyCorrectBoxes=0;
		int currentTry=0 ;
		while (!checkIfAllBlocksFullyCorrect() &&currentTry != tries){
			if(true==this.testFieldForRightAmountOfBoxesPerLine()) {
				for(int i=0;i<this.getNumberHints().size();i++) {
					this.getNumberHints().get(i).correctStreakOfFreeBlocks(allBlocks);
//					confirmBlocksWithVerticalConfirmedAndHorizontal();
					confirmNumberHintsBasedIfAllBlocksFullyCorrectInRow();
					}				
				}				
			else {
//				setNonConfirmedAmountOfBoxesToUnknown();
				for (Block block : getAllBlocks()) {
					block.assignRandomBombBox();
				}
			}
			counterRightAmountOfBoxes=getAmountOfRightAmountOfBoxesInHints();
			
			currentTry++;
//			System.out.println("Try Number: "+currentTry);
		}
		confirmNumberHintsBasedIfAllBlocksFullyCorrectInRow();
		}
			
	private void confirmNumberHintsBasedIfAllBlocksFullyCorrectInRow() {
		
		for (NumberHint numberHint: numberHints) {
			int amountOfFullyCorrectBoxes=0;
			for(int i=0; i<allBlocks.size();i++) {
			if(numberHint.isInLine(allBlocks.get(i))) {
				if(allBlocks.get(i).isFullyCorrectBox()) {
					amountOfFullyCorrectBoxes++;
				}
				
			}
			}
//			System.out.println("Anzahl an komplett Korrekten boxen: "+amountOfFullyCorrectBoxes);
//			scan1.nextLine();
			if (amountOfFullyCorrectBoxes == fieldSize) {
				numberHint.setAllCorrect(true);
//				System.out.println("NumberHint auf True gesetzt: "+numberHint);
//				scan1.nextLine();
			}
		}
		
		
	}

	public int getNumberOfAllBlocksFullyCorrect() {
		int amountOfFullyCorrect=0;
		for(Block block: allBlocks) {
			if(block.isFullyCorrectBox()) {
				amountOfFullyCorrect++;
			}
		}
		return amountOfFullyCorrect;
	}

	private boolean checkIfAllBlocksFullyCorrect() {
		int amountOfFullyCorrect=0;
		for(Block block: allBlocks) {
			if(block.isFullyCorrectBox()) {
				amountOfFullyCorrect++;
			}
			}
		if(amountOfFullyCorrect==allBlocks.size()) {
			return true;
		}
		return false;
	}

	public int getAmountOfRightAmountOfBoxesInHints() {
		int counter=0;
		for (NumberHint hint : this.numberHints) {
			if(hint.isCorrectNumberOfBoxes()) {
				counter++;
			}
		}
		return counter;
	}

	public int getAmountOfLockedHints() {
		int counter=0;
		for (NumberHint hint : this.numberHints) {
			if(hint.isAllCorrect()) {
				counter++;
			}
		}
		return counter;
		
	}
//				
//			}
//			
//			for (int i=0;i<this.getAllBlocks().size();i++) {
//					this.getAllBlocks().get(i).assignRandomBombBox();		
//			}
//			
//			
//			
//			
//			
//			currentTry++;
//			System.out.println("Try Number: "+currentTry);
//			counterRightHints=0;
//			for(int i=0;i<this.getNumberHints().size();i++) {				
//			if (this.getNumberHints().get(i).isAllCorrect()) {
//				counterRightHints++;
//			}
//			}
//			if (counterRightHints!=this.numberHints.size()) {
//				
//				resetIsAllCorrect();
//			}
//		}
//		System.out.println(counterRightHints);
//	}

	//spielFeld mit dem Status kopieren
	 public PlayingField copyPlayingField() {
	        // Erstelle eine neue Instanz von PlayingField mit derselben Feldgröße
	        PlayingField playingFieldCopy = new PlayingField(this.fieldSize);
	        
	        // Initialisiere die Listen neu, um sicherzustellen, dass sie unabhängig sind
	        playingFieldCopy.allBlocks = new ArrayList<Block>();
	        for (Block block : this.allBlocks) {
	            // Füge eine Kopie jedes Blocks zur neuen Liste hinzu
	            playingFieldCopy.allBlocks.add(block.copy());
	        }
	        
	        playingFieldCopy.numberHints = new ArrayList<NumberHint>();
	        for (NumberHint hint : this.numberHints) {
	            // Füge eine Kopie jedes NumberHints zur neuen Liste hinzu
	            playingFieldCopy.numberHints.add(hint.copy());
	        }
	        
	        // Keine Notwendigkeit, fieldSize erneut zu setzen, da es bereits im Konstruktor gesetzt wurde
	        
	        return playingFieldCopy;
	    }

	 public void preBruteForceAssignments() {
		    int totalCombinations = (int) Math.pow(2, fieldSize); // Vorab berechnen
		    ArrayList<String> correctPatterns = new ArrayList<>();

		    int count = 0;

		    for (int h = 0; h < numberHints.size(); h++) {
		    	if(!numberHints.get(h).isAllCorrect()) {
		        correctPatterns.clear();

		        // Sammeln aller Blöcke, die in Linie mit dem aktuellen NumberHint liegen
		        ArrayList<Block> inLineBlocks = new ArrayList<>();
		        ArrayList<Boolean> fixedStates = new ArrayList<>(); // Speichert, ob ein Block festgelegt ist
		        for (Block block : allBlocks) {
		            if (numberHints.get(h).isInLine(block)) {
		                inLineBlocks.add(block);
		                fixedStates.add(block.isFullyCorrectBox()); // Speichert den festgelegten Zustand
		            }
		        }
		        
		        
		        int startNumberPrevious= totalCombinations;
		        	ArrayList<ArrayList<String>> validPatterns = new ArrayList<ArrayList<String>>();
		        	for (int i=0;i< numberHints.get(h).getNumbers().size();i++) {
		        		ArrayList<String> list = new ArrayList<String>();
		        		int testNumber=(int)Math.pow(2, numberHints.get(h).getNumbers().get(i)) -1;
		        		int startNumber= (int) (testNumber* Math.pow(2, numberHints.get(h).getNumbersAndSpacesOnRight(i)));
		        		int maxNumber;
		        		if(i==0) {
		        		maxNumber= totalCombinations;
		        		}
		        		else {
		        			maxNumber= (int) Math.pow(2, fieldSize-numberHints.get(h).getNumbersAndSpacesOnLeft(i)) ;
		        		}
		        		startNumberPrevious = startNumber;
		        		while(startNumber< maxNumber) {
		        			list.add(Integer.toBinaryString(startNumber));
		        			startNumber*=2;
		        		}
		        		validPatterns.add(list);
//		        		System.out.println("Liste Hinzugefügt zu Valid pattern");
		        	}
		        	
		        	ArrayList<String> possibleSolutions= new ArrayList<String>();
//		        	System.out.println("Valid Patterns: " +validPatterns);
		        	addCombinations(validPatterns,0,0,possibleSolutions);
//		        	System.out.println("Possible Solutions: "+ possibleSolutions);
//		        	scan1.nextLine();
		        
		        
		        	for (String possibleSolution: possibleSolutions) {
		        	int i=Integer.parseInt(possibleSolution,2);
		             
		                StringBuilder binaryPattern = new StringBuilder(String.format("%" + fieldSize + "s", Integer.toBinaryString(i)).replace(' ', '0'));
		                
		                // Anpassung des binären Musters für festgelegte Blöcke
		                for (int j = 0; j < fieldSize; j++) {
		                    if (fixedStates.get(j)) {
		                        if (inLineBlocks.get(j).isFullyCorrectBox()) {
		                            binaryPattern.setCharAt(j, inLineBlocks.get(j).isFreeBox() ? '1' : '0');
		                        }
		                    }
		                }

//		                System.out.println("i: " + i + ", Binär: " + binaryPattern.toString());

		                for (int j = 0; j < fieldSize; j++) {
		                    if (binaryPattern.charAt(j) == '1') {
		                        inLineBlocks.get(j).setFreeBox(true); // Setzt keine Bombe, wenn das Bit gesetzt ist
		                    } else {
		                        inLineBlocks.get(j).setBombBox(true); // Setzt eine Bombe, wenn das Bit nicht gesetzt ist
		                    }
		                }
		                testFieldForRightAmountOfBoxesPerLine();
		                if (numberHints.get(h).correctStreakOfFreeBlocks(inLineBlocks)) {
		                    
		                    if (!correctPatterns.contains(binaryPattern.toString())) {
		                        correctPatterns.add(binaryPattern.toString());
		                        numberHints.get(h).addPossibleAmountOfRightStreaks(1);

		                        count++;
		                        
		                    }	                 	                    
		                }
		            }
		        
		        if (!correctPatterns.isEmpty()) {
		            applyConsistentBlockStates(correctPatterns, inLineBlocks);
		        }
		    }
			confirmNumberHintsBasedIfAllBlocksFullyCorrectInRow();
		}
		    }
	 
	 

	 
	 public static void addCombinations(ArrayList<ArrayList<String>> arrays, int arrayIndex, int sum, ArrayList<String> result) {
	        if (arrayIndex == arrays.size()) {
	            // Wenn wir das Ende der Liste erreicht haben, fügen wir die Summe zur Ergebnisliste hinzu
	            result.add(Integer.toBinaryString(sum));
	        } else {
	            // Andernfalls addieren wir jede Zahl im aktuellen Array zur Summe und rufen die Funktion rekursiv auf
	            for (String num : arrays.get(arrayIndex)) {
	                addCombinations(arrays, arrayIndex + 1, sum | Integer.parseInt(num, 2), result);
	            }
	        }
	    }

	private void applyConsistentBlockStates(ArrayList<String> patterns, ArrayList<Block> blocks) {
//		    System.out.println("Anfang der Methode applyConsistentBlockStates");
//		    scan1.nextLine();
		    
//		    System.out.println("Gesammelte Muster (patterns): " + patterns);
//		    scan1.nextLine();
		    
		    for (int i = 0; i < fieldSize; i++) { // Gehe durch jede Position
		        final int index = i;
		        char firstState = patterns.get(0).charAt(i);
		        boolean consistent = patterns.stream()
		                                     .allMatch(p -> p.charAt(index) == firstState); // Überprüfe Konsistenz

//		        System.out.println("Überprüfung der Position " + i + ": " + firstState + " ist konsistent: " + consistent);
//		        scan1.nextLine();

		        if (consistent) { // Wenn alle Muster an dieser Position konsistent sind
//		            System.out.println("Anwenden des konsistenten Zustands für Block an Position " + i);
		            if (firstState == '0') {
		                blocks.get(i).setBombBox(true);
		                blocks.get(i).setFullyCorrectBox(true);
//		                System.out.println("Block " + i + " als Bombe markiert.");
		            } else {
		                blocks.get(i).setFreeBox(true);
		                blocks.get(i).setFullyCorrectBox(true);
//		                System.out.println("Block " + i + " als frei markiert.");
		            }
//		            scan1.nextLine();
		        }
		    }

//		    System.out.println("Ende der Methode applyConsistentBlockStates");
//		    scan1.nextLine();
		}

}

		

	

	
