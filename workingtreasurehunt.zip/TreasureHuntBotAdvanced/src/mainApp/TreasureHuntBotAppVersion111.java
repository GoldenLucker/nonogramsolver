package mainApp;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.Properties;
import java.util.Scanner;
import java.net.HttpURLConnection;
import java.io.OutputStream;

import javax.activation.DataHandler;
import javax.imageio.ImageIO;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.*;
import java.net.URI;
import org.sikuli.basics.Settings;
import org.sikuli.script.*;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
//import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.web.WebView;

import javax.swing.*;
import java.awt.*;


public class TreasureHuntBotAppVersion111 {
	// Globale Variablen für den Webhook-Link
    private static final String WEBHOOK_URL = "https://discord.com/api/webhooks/1335616329406877808/CcvLnmXpPpEImqMGNnYti9TYLLxK2PvQusJUUdgkn_pjnjyEJMkTUSfD_jjvafTDD-9d";
	final static Object lock = new Object();
	private static int counterSec = 0;
	static JFrame frameScreenshot;
	static double ScalingPercent;
	static ArrayList<Pattern> allPatterns = new ArrayList<Pattern>();
	static Scanner scan = new Scanner(System.in);
	static int restartCounter;
	static int amountOfCorrectBoxes=0;
	static PlayingField playingField;
	static PlayingField playingFieldSave;
	
	public static void sendDiscordNotification() throws Exception {
	    InetAddress ip = InetAddress.getLocalHost();
	    System.out.println("IP-Adresse: " + ip.getHostAddress());
	    System.out.println("Hostname: " + ip.getHostName());

	    // Deine Webhook-URL
	    String webhookUrl = "https://discord.com/api/webhooks/1335616329406877808/CcvLnmXpPpEImqMGNnYti9TYLLxK2PvQusJUUdgkn_pjnjyEJMkTUSfD_jjvafTDD-9d";

	    // Erstelle den JSON Payload
	    String jsonPayload = "{"
	        + "\"content\": \"Deine Java-Anwendung wurde gestartet. HostName: " + ip.getHostName() + " IP: " + ip.getHostAddress() + "\""
	        + "}";

	    // Stelle eine Verbindung zum Webhook her
	    URL url = new URL(webhookUrl);
	    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	    connection.setRequestMethod("POST");
	    connection.setRequestProperty("Content-Type", "application/json");
	    connection.setDoOutput(true);

	    // Sende den JSON-Payload an den Webhook
	    try (OutputStream os = connection.getOutputStream()) {
	        byte[] input = jsonPayload.getBytes("utf-8");
	        os.write(input, 0, input.length);
	    }

	    // Überprüfe den Antwortcode
	    int responseCode = connection.getResponseCode();
	    if (responseCode == HttpURLConnection.HTTP_OK) {
	        System.out.println("Nachricht erfolgreich gesendet!");
	    } else {
	        System.out.println("Fehler beim Senden der Nachricht. Response Code: " + responseCode);
	    }
	}

	
	public static void main(String[] args) {

        // Erstelle den Swing-Frame
        JFrame frame = new JFrame("Solver");
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setLocationRelativeTo(null);

        // Panel für Werbebanner (JavaFX)
        JFXPanel jfxPanel = new JFXPanel();
        jfxPanel.setPreferredSize(new Dimension(350, 300)); // Größe passend zum Ad-Banner

        // Panel für Steuerungselemente (Timer, Buttons)
        JPanel controlPanel = new JPanel(new FlowLayout());
        JLabel timerLabel = new JLabel("Time: 0 Seconds");
        JButton solveButton = new JButton("Solve");
        JButton cancelButton = new JButton("Close");

        controlPanel.add(timerLabel);
        controlPanel.add(solveButton);
        controlPanel.add(cancelButton);

        // Füge Panels in das Frame ein
        frame.add(jfxPanel, BorderLayout.CENTER);
        frame.add(controlPanel, BorderLayout.SOUTH);

        // Passe die Frame-Größe an (Banner + Steuerungselemente)
        frame.pack();
        frame.setResizable(false);
        frame.setVisible(true);

        // JavaFX-Code zum Laden des Ad-Banners
        Platform.runLater(() -> {
            WebView webView = new WebView();
            webView.getEngine().setJavaScriptEnabled(true);
            webView.getEngine().setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36");
            String htmlContent = "<html>"
                    + "<head>"
                    + "  <meta charset=\"UTF-8\">"
                    + "  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">"
                    + "  <title>Ad Example</title>"
                    + "</head>"
                    + "<body>"
                    + "  <!-- Ad Script -->"
                    + "  <script type=\"text/javascript\">"
                    + "    atOptions = {"
                    + "        'key' : 'a2bff68674c3ff040eba95fa6bd30a2e',"
                    + "        'format' : 'iframe',"
                    + "        'height' : 250,"
                    + "        'width' : 300,"
                    + "        'params' : {}"
                    + "    };"
                    + "  </script>"
                    + "  <script type=\"text/javascript\" src=\"https://www.highperformanceformat.com/a2bff68674c3ff040eba95fa6bd30a2e/invoke.js\"></script>"
                    + "</body>"
                    + "</html>";
            webView.getEngine().loadContent(htmlContent);
            jfxPanel.setScene(new Scene(webView));
        });

        // Timer für die Anzeige der verstrichenen Sekunden
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                counterSec++;
                timerLabel.setText("Time: " + counterSec + " Seconds");
            }
        });
        timer.start();

        // ActionListener für den "Solve"-Button
        solveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                synchronized (lock) {
                    counterSec = 0;
                    lock.notify();
                }
            }
        });

        // ActionListener für den "Close"-Button
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                System.exit(0);
            }
        });

        // Optional: ESC-Taste zum Schließen des Fensters
        frame.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    frame.dispose();
                    System.exit(0);
                }
            }
        });

        // Beispiel-Schleife für Spiel-Logik (hier als Platzhalter)
        new Thread(() -> {
            while (true) {
                synchronized (lock) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
                // Verstecke das Fenster während der Ausführung der Spiel-Logik
                SwingUtilities.invokeLater(() -> frame.setVisible(false));

                // Platzhalter: Hier Ihre Spiel-Logik ausführen
                try {
                    executeGameLogic();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    System.exit(0);
                }

                // Nach Ausführung der Logik wieder das Fenster anzeigen
                SwingUtilities.invokeLater(() -> frame.setVisible(true));
            }
        }).start();
    }
        private static void executeGameLogic() throws IOException, URISyntaxException, InterruptedException, FindFailed {
        	allPatterns = new ArrayList<Pattern>();
        	amountOfCorrectBoxes=0;
        	Thread.sleep(2000);
        	// Hier beginnt der Rest deines Programms im Hintergrund.
            // ...
    		//Initializer.initializeWindow();
    		int fieldSize = getFieldSize();
    		System.out.println(fieldSize);

    		int SIZE= fieldSize;
    		

    		switch(fieldSize) {
    		case 5: playingField = InitializerSmall.initialize(SIZE);
    		break;
    		case 7: playingField = InitializerMedium.initialize(SIZE);
    		break;
    		case 10: playingField = InitializerBig.initialize(SIZE);
    		break;
    		case 15: playingField = InitializerBiggest.initialize(SIZE);
    		}

    		solveGame();
    		clickBoxes();
//    		System.exit(0);
		// TODO Auto-generated method stub
		
	}
		

	
	private static void scannedImageOutput(BufferedImage screenImage) {

		try {
		    // Speichern des bearbeiteten Screenshots
		    ImageIO.write(screenImage, "PNG", new File("InitialScreenShot.png"));
		} catch (Exception e) {
		    e.printStackTrace();
		}
	}
	
	
	 private static int getFieldSize() throws IOException, URISyntaxException, InterruptedException, FindFailed {
	        Screen screen = new Screen();
	        BufferedImage screenImage = screen.capture().getImage();
	        // Scanned image output (method implementation not shown in the snippet)
	        scannedImageOutput(screenImage);
	        screen.mouseMove(new Location((screenImage.getWidth() - 1), (screenImage.getHeight() - 1)));
	        screen.getBottomRight();
	        screen.setAsScreen();
	        if (screenImage.getHeight() != 1080) {
	            ScalingPercent = ((double) 100) / screenImage.getHeight() * 1080 / 100;
	            System.out.println(ScalingPercent);
	            int newWidth = (int) Math.round(screenImage.getWidth() * (ScalingPercent));
	            int newHeight = (int) Math.round(screenImage.getHeight() * (ScalingPercent));
	            System.out.println(newWidth);
	            System.out.println(newHeight);
	            BufferedImage scaledImage = new BufferedImage(newWidth, newHeight, screenImage.getType());
	            Graphics2D g2d = scaledImage.createGraphics();
	            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
	            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
	            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

	            // Draw the original image, scaled to the new size
	            g2d.drawImage(screenImage, 0, 0, newWidth, newHeight, null);
	            g2d.dispose();
	            screenImage = scaledImage;

	            JFrame frame = new JFrame("Image Viewer");
	            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	            frame.setUndecorated(true);
	            ImageIcon imageIcon = new ImageIcon(screenImage);
	            JLabel label = new JLabel(imageIcon);
	            frame.getContentPane().add(label);
	            frame.pack();
	            frame.setLocation(0, 0);
	            frame.setVisible(true);
	            frameScreenshot = frame;
	        }
	       
	    
			//screenImage.getWidth();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    try {
		        ImageIO.write(screenImage, "png", baos);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		    byte[] imageBytes = baos.toByteArray();

		    // Convert byte array to Base64 encoded string
		    String encodedImage = Base64.getEncoder().encodeToString(imageBytes);
		    
		    
		    
//			ImageIO imageIO = new ImageIO();
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			InputStream inputStream = classLoader.getResourceAsStream("ImagesOfDetection/General/5.png");
			InputStream inputStream1 = classLoader.getResourceAsStream("ImagesOfDetection/General/7.png");
			InputStream inputStream2 = classLoader.getResourceAsStream("ImagesOfDetection/General/10.png");
			InputStream inputStream3 = classLoader.getResourceAsStream("ImagesOfDetection/General/15.png");
			
			BufferedImage image1 = ImageIO.read(inputStream);
			BufferedImage image2 = ImageIO.read(inputStream1);
			BufferedImage image3 = ImageIO.read(inputStream2);
			BufferedImage image4 = ImageIO.read(inputStream3);
			
//			System.out.println(pattern5.getClass().getName());
//			
//			File jarFile = new File(TreasureHuntBotAppVersion1.class.getProtectionDomain().getCodeSource().getLocation().toURI());
//			System.out.println(jarFile);
//			scan.nextLine();			
			Pattern pattern5 = new Pattern(image1).similar(0.9);
			Pattern pattern7 = new Pattern(image2).similar(0.9);
			Pattern pattern10 = new Pattern(image3).similar(0.9);
			Pattern pattern15 = new Pattern(image4).similar(0.9);
			
			allPatterns.add(pattern5);
			allPatterns.add(pattern7);
			allPatterns.add(pattern10);
			allPatterns.add(pattern15);
			
			
			int matchedPatternIndex=-1;
			    for(int i=0; i<allPatterns.size();i++) {
			    	try {
			    		Iterator<Match> matches = screen.findAll(allPatterns.get(i));
			    		while (matches.hasNext()) {
			    			matchedPatternIndex =i;
			                Match match = matches.next();
			    		System.out.println(match.getX()+"/"+match.getY() +" " + matchedPatternIndex);
//			    		scan.nextLine();
		
			    		switch(matchedPatternIndex) {					    
					    case 0 : return 5;
					    case 1 : return 7;
					    case 2 : return 10;
					    case 3 : return 15;
					    default:System.out.println("Nicht gefunden");
					    }			    		
			    	}
			    	}
			    	catch (FindFailed e)
			    	{
			    		System.out.println("Kein Match Gefunden.");
			    	}
			    	
	            }
			    
			System.out.println("Feld nicht gefunden. Bitte manuell eingeben:");
//		     Anzeigen eines Dialogfensters zur Eingabe der Zahl
			frameScreenshot.setVisible(false);
			while (true) {
		    String input = JOptionPane.showInputDialog("Fieldsize not detected. Enter Fieldsize manually (Length): 5, 7, 10, 15");
		    try {
		    	if(input == null) {
		    		System.exit(0);
		    	}
		    	int inputNumber = Integer.parseInt(input);	    	
		    	if(!(inputNumber != 5 && inputNumber !=7 && inputNumber != 10 && inputNumber != 15)) {
		        inputNumber = Integer.parseInt(input);
		        return inputNumber;
		    	}
		    	
		    	else
		    		 JOptionPane.showMessageDialog(null, "Invalid number.");
		        
		    } catch (NumberFormatException e) {
		        JOptionPane.showMessageDialog(null, "Invalid number.");
		        
		    }
			}
	}


		
		private static void clickBoxes() {
			Screen screen = new Screen();
			if (frameScreenshot != null) {
				frameScreenshot.setVisible(false);
				frameScreenshot.dispose();
			}
			else ScalingPercent=1;
			
		for(NumberHint numberHint : playingField.getNumberHints()) {
			if(numberHint.getYPosition()==0 && numberHint.getXPosition()%2==1) {
				for (int i=0;i<playingField.getAllBlocks().size();i++) {
					
				if(numberHint.isInLine(playingField.getAllBlocks().get(i))&& playingField.getAllBlocks().get(i).isFullyCorrectBox()&& playingField.getAllBlocks().get(i).isFreeBox()) {
					Location point = new Location(playingField.getAllBlocks().get(i).getxPositionCoordinates()/ScalingPercent, playingField.getAllBlocks().get(i).getyPositionCoordinates()/ScalingPercent);
						try {
							Settings.MoveMouseDelay= 0.2f;
							screen.click(point);
							Settings.MoveMouseDelay= 0.1f;
							point.setX((playingField.getAllBlocks().get(i).getxPositionCoordinates()+5)/ScalingPercent);
							screen.click(point);
							  
						} catch (FindFailed e) {
							e.printStackTrace();
						}
					}
				}				
				}
			if(numberHint.getYPosition()==0 && numberHint.getXPosition()%2==0) {
				for (int i=playingField.getAllBlocks().size()-1;i>=0;i--) {
					
				if(numberHint.isInLine(playingField.getAllBlocks().get(i))&& playingField.getAllBlocks().get(i).isFullyCorrectBox()&& playingField.getAllBlocks().get(i).isFreeBox()) {
					Location point = new Location(playingField.getAllBlocks().get(i).getxPositionCoordinates()/ScalingPercent, playingField.getAllBlocks().get(i).getyPositionCoordinates()/ScalingPercent);
						try {
							Settings.MoveMouseDelay= 0.2f;
							screen.click(point);
							Settings.MoveMouseDelay= 0.1f;
							point.setX((playingField.getAllBlocks().get(i).getxPositionCoordinates()+5)/ScalingPercent);
							screen.click(point);
							  
						} catch (FindFailed e) {
							e.printStackTrace();
						}
					}
				}				
				}
			
			}
			
		}
		
	

		private static void clickBoxes2() {
			Screen screen = new Screen();
			
			
		for(Block block: playingField.getAllBlocks()) {
			if(block.isFreeBox()&&block.isFullyCorrectBox()) {
				block.getVerticalNumberIndex(playingField.getNumberHints());
				
				Location point = new Location(block.getxPositionCoordinates(),block.getyPositionCoordinates());
				try {
					Settings.MoveMouseDelay= 0.1f;
					screen.click(point);
					Settings.MoveMouseDelay= 0.1f;
					point.setX(block.getxPositionCoordinates()+5);
					screen.click(point);
					  
				} catch (FindFailed e) {
					e.printStackTrace();
				}

			}
		}
		
	}



		private static void checkIfSolved() {
			if (amountOfCorrectBoxes< playingField.getNumberOfAllBlocksFullyCorrect()) {
			amountOfCorrectBoxes=playingField.getNumberOfAllBlocksFullyCorrect();
			if(playingField.getAllBlocks().size()==playingField.getNumberOfAllBlocksFullyCorrect()) {
				//System.out.println(playingField.getAllBlocks());
				//System.out.println("Game Solved");
				//System.out.println("Mit so vielen Restarts: "+ restartCounter);
				//System.out.println("SoViele Locked Boxes: "+playingField.getNumberOfAllBlocksFullyCorrect());
				//System.out.println("SoViele Locked NumberHints: "+ playingField.getAmountOfLockedHints());
//				scan.nextLine();
			}
			else {
				//System.out.println(playingField.getAllBlocks());
				//System.out.println("Wurde nicht Gelöst.. Neustart");
				//System.out.println("SoViele Locked Boxes: "+playingField.getNumberOfAllBlocksFullyCorrect());
				//System.out.println("SoViele Locked NumberHints: "+ playingField.getAmountOfLockedHints());
				
//				scan.nextLine();			
				preBruteForceRNG();
			}
			}
			//System.out.println("Wurde nicht Gelöst.. Neustart");
			//System.out.println("SoViele Locked Boxes: "+playingField.getNumberOfAllBlocksFullyCorrect());
			//System.out.println("SoViele Locked NumberHints: "+ playingField.getAmountOfLockedHints());
			//System.out.println("Keine weitere Veränderung mit saveStuff...");
//			scan.nextLine();
			playingFieldSave =playingField.copyPlayingField();			
//			clickBoxes();
//			scan.nextLine();
//			bruteForceRNG();
	}
		private static void checkIfSolvedAfterRNG() {

			if(playingField.getAllBlocks().size()==playingField.getNumberOfAllBlocksFullyCorrect()) {
				//System.out.println(playingField.getAllBlocks());
				//System.out.println("Game Solved");
				//System.out.println("Mit so vielen Restarts: "+ restartCounter);
				//System.out.println("SoViele Locked Boxes: "+playingField.getNumberOfAllBlocksFullyCorrect());
				//System.out.println("SoViele Locked NumberHints: "+ playingField.getAmountOfLockedHints());
//				scan.nextLine();
			}
			else {
				//System.out.println(playingField.getAllBlocks());
				//System.out.println("Wurde nicht Gelöst.. Neustart");
				//System.out.println("SoViele Locked Boxes: "+playingField.getNumberOfAllBlocksFullyCorrect());
				//System.out.println("SoViele Locked NumberHints: "+ playingField.getAmountOfLockedHints());
				
//				scan.nextLine();			
				restartBoard();
				bruteForceRNG();
			}			
			
	}



		private static void restartBoard() {
			playingField = playingFieldSave.copyPlayingField();
			restartCounter++;
		    //System.out.println("Spielbrett wurde zurückgesetzt.");
	}
		
		//Nach playingField.testField(); ausführen um "True Reihen" auf alle Boxen zu Locken.
//	private static void confirmBoxes() {
//		for(int i=0;i<playingField.getAllBlocks().size();i++) {
//			for(int j=0;j<playingField.getNumberHints().size();j++) {
//		if( playingField.getNumberHints().get(j).isInLine(playingField.getAllBlocks().get(i))&& playingField.getNumberHints().get(j).isCorrect()) {
//			playingField.getAllBlocks().get(i).setDefCorrect(true);
//		}
//		}
//	}
//	}
	//ausgabe aller Linien mit True oder False je nachdem ob richtig oder Falsch..
	private static void testField() {
		for(int i=0;i<playingField.getNumberHints().size();i++) {
			//System.out.println("Korrekte Anzahl an FreeFelder: "+ playingField.getNumberHints().get(i).isCorrectNumberOfBoxes()+ "\t mit NumberHint: "+ playingField.getNumberHints().get(i).toString()); 
			}
		
	}

	private static void solveGame() {
		for (int i =0; i<playingField.getNumberHints().size();i++) {
//			//System.out.println("HIIIIIIIII");
			if(playingField.getNumberHints().get(i).getAddedNumbersAndSpaces() == playingField.getFieldSize() || playingField.getNumberHints().get(i).getAddedNumbersAndSpaces()==0) {
				//testField();
				determineFieldsFull(playingField.getNumberHints().get(i));
				testField();//Initial alle felder
				////System.out.println(playingField.getAllBlocks());
			}
		}
			//System.out.println("PreBruteForceStart: "+ playingField.getAllBlocks());
			//System.out.println(playingField.getNumberHints());
//			scan.nextLine();
			preBruteForceRNG();
//			
//			scan.nextLine();
		
		
//		bruteForceRNG();
		//getAllBombPositions();
//		stepTwo();
	}
	private static void preBruteForceRNG() {
		playingField.preBruteForceAssignments();
		testField();
		checkIfSolved();
	}
	
	private static void bruteForceRNG() {
		playingField.bruteForce(10000);
		testField();
		checkIfSolvedAfterRNG();
	}
	
	
	private static Integer getUnknownFieldsInAStreakAndFreeFields(NumberHint numberHint) {
		for(int i=0;i<playingField.getAllBlocks().size();i++) {
			int yPositionAnliegendÜber=playingField.getAllBlocks().get(i).getYPosition()+1;
			for(int j=0;j<playingField.getAllBlocks().size();j++) {
				if(playingField.getAllBlocks().get(j).getYPosition() == yPositionAnliegendÜber && playingField.getAllBlocks().get(i).isUnknownBox() == playingField.getAllBlocks().get(j).isUnknownBox()) {
//				//System.out.println("HIII");
					
				}
		}
		}
		return null;
		}

	private static void determineFieldsFull(NumberHint numberHint) {
		if (numberHint.getAddedNumbers()==0) {
			for(int i=0; i<playingField.getAllBlocks().size();i++)
				if(numberHint.isInLine(playingField.getAllBlocks().get(i))) {
				playingField.getAllBlocks().get(i).setBombBox(true);
				playingField.getAllBlocks().get(i).setFullyCorrectBox(true);
				numberHint.setAllCorrect(true);
				}
		}
		
		if (numberHint.getAddedNumbers() == numberHint.getAddedNumbersAndSpaces()){
			if (numberHint.getNumbers().size() == 1) {
				if (numberHint.getXPosition()>=1) {
					for (int i= 0;i<playingField.getAllBlocks().size();i++) {
						if (playingField.getAllBlocks().get(i).xPosition== numberHint.getXPosition()) {
							playingField.getAllBlocks().get(i).setFreeBox(true);
							playingField.getAllBlocks().get(i).setFullyCorrectBox(true);
						}
					}
				}
				if (numberHint.getYPosition()>=1) {
					for (int i= 0;i<playingField.getAllBlocks().size();i++) {
						if (playingField.getAllBlocks().get(i).yPosition== numberHint.getYPosition()) {
							playingField.getAllBlocks().get(i).setFreeBox(true);
							playingField.getAllBlocks().get(i).setFullyCorrectBox(true);
						}
					}
				}
			}
		}
		else {//für alle Spalten werden Bomben ermittelt basierend auf Hint
			////System.out.println("NumberHintSize:" +numberHint.getNumbers().size());
			if (numberHint.getXPosition()>=1) {
				for (int i=0;i<playingField.getAllBlocks().size();i++) {
					if (playingField.getAllBlocks().get(i).xPosition == numberHint.getXPosition()) {
						for (int j=0;j<numberHint.getNumbers().size();j++) {
							if (numberHint.getAddedNumbersToIndex(j) +1== playingField.getAllBlocks().get(i).getYPosition()) {
								playingField.getAllBlocks().get(i).setBombBox(true);
								playingField.getAllBlocks().get(i).setFullyCorrectBox(true);
							}
						}
					}
					
				}
			}// für Alle Reihen werden alle Bomben Ermittelt basierend auf hint
			if (numberHint.getYPosition()>=1) {
				for (int i=0;i<playingField.getAllBlocks().size();i++) {
					if (playingField.getAllBlocks().get(i).yPosition == numberHint.getYPosition()) {
						for (int j=0;j<numberHint.getNumbers().size();j++) {
							if (numberHint.getAddedNumbersToIndex(j) +1== playingField.getAllBlocks().get(i).getXPosition()) {
								playingField.getAllBlocks().get(i).setBombBox(true);
								playingField.getAllBlocks().get(i).setFullyCorrectBox(true);
							}
						}
					}
				}
			}
			
			setBlocksInNumberLineToFree(numberHint);// to free which dont Contain bombs in line of numberHint
			//Alle Blöcke in den Aufgerufenen Linien welche nicht Als bombe Festgelegt wurden-> als Frei Festlegen
			
		}
	}

	
	public static void setBlocksInNumberLineToFree(NumberHint numberHint) {
		for(int o=0; o<playingField.getAllBlocks().size();o++) {
			if(numberHint.isInLine(playingField.getAllBlocks().get(o)) &! playingField.getAllBlocks().get(o).isBombBox()) {
				playingField.getAllBlocks().get(o).setFreeBox(true);
				playingField.getAllBlocks().get(o).setFullyCorrectBox(true);
			}
			}
	}
	// only works if Not Confirmed
	public static void setBlocksInNumberLineToUnknown(NumberHint numberHint) {
		for(int o=0; o<playingField.getAllBlocks().size();o++) {
			if(numberHint.isInLine(playingField.getAllBlocks().get(o)) &! playingField.getAllBlocks().get(o).isDefCorrectNumberOfBoxes()) {
				playingField.getAllBlocks().get(o).setUnknownBox(true);
			}
		}
	}
	
	
	/*public static void sendEmailNotification(String encodedImage, byte[] imageBytes) throws UnknownHostException {
		
        InetAddress ip = InetAddress.getLocalHost();
        System.out.println("IP-Adresse: " + ip.getHostAddress());
        System.out.println("Hostname: " + ip.getHostName());
    
    String host = "smtp.gmail.com";
    String port = "587";
    //String username = "#@gmail.com";
    //String password = "#";

    // Empfängeradresse
    String recipient = "animaljam629@gmail.com";
    
    // Betreff und Nachrichtentext
    String subject = "Programm gestartet";
    String messageText = "Deine Java-Anwendung wurde gestartet. HostName: "+ ip.getHostName()+" IP: "+ ip.getHostAddress() ;
    
    // Einstellungen für die Verbindung zum SMTP-Server
    Properties props = new Properties();
    props.put("mail.smtp.host", host);
    props.put("mail.smtp.port", port);
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.starttls.enable", "true");
    
    // Authentifizierung mit dem SMTP-Server
    Session session = Session.getInstance(props, new javax.mail.Authenticator() {
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(username, password);
        }
    });
    
    try {
        // Erstellung der Nachricht
        Message message = new MimeMessage(session);
        MimeBodyPart attachmentBodyPart = new MimeBodyPart();
        attachmentBodyPart.setDataHandler(new DataHandler(new ByteArrayDataSource(imageBytes, "image/png")));
        attachmentBodyPart.setFileName("screenshot.png");
        MimeMultipart multipart = new MimeMultipart();
        MimeBodyPart textBodyPart = new MimeBodyPart();
        
        textBodyPart.setText(messageText);
        multipart.addBodyPart(attachmentBodyPart);
        multipart.addBodyPart(textBodyPart);
        
        message.setFrom(new InternetAddress(username));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
        message.setSubject(subject);
        message.setText(messageText);
        message.setContent(multipart);
        
        // Versenden der Nachricht
        Transport.send(message);
//        System.out.println("E-Mail-Benachrichtigung erfolgreich versendet.");
    } catch (MessagingException e) {
        throw new RuntimeException(e);
    }
} */
	

}
