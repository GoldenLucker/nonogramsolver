package mainApp;

import java.io.IOException;

public class InitializerTest {

	public static void main(String[] args) throws InterruptedException, IOException {
		InitializerBiggest.initialize(15);
		

	}

}
