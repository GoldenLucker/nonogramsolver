package mainApp;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

import javax.imageio.ImageIO;

import org.sikuli.script.*;




public class InitializerSmall {
	
	static int imageNumber;
	static ArrayList<Pattern> allPattern = new ArrayList<Pattern>();
	static ArrayList<NumberElement> numberElements = new ArrayList<NumberElement>();
	static PlayingField playingField;
	
	static int distanceBetweenNextNumberMaxX= 100;
	static int distanceBetweenNextNumberMaxY= 50;
	static int distanceBetweenNextLineYMin= 50;
	static int distanceBetweenNextLineYMax= 200;
	
	static int distanceBetweenNextLineXMax= 200;
	
	static int indexFirstNumberYAxis;
	
	static int currentIndex;
	public static PlayingField initialize(int SIZE) throws IOException {
		
		playingField = new PlayingField(SIZE);
		int counter=0;
		allPattern = new ArrayList<Pattern>();
		numberElements = new ArrayList<NumberElement>();
		addPicturesToPattern();
		
		
		
		Screen screen = new Screen();
		
		BufferedImage screenImage = screen.capture().getImage();	
		try {
			for (int i=0;i<allPattern.size();i++) {
			Iterator<Match> matches = screen.findAll(allPattern.get(i));
			
					while (matches.hasNext()) {
		                Match match = matches.next();
		                // Hier können Sie mit dem gefundenen Match arbeiten,
		                // z.B. seine Position ausgeben oder darauf klicken.
		           //     //System.out.println("Gefundenes Bild an Position: " + match.getRect());
		                counter++;
		                //System.out.println(counter);
		                int fileName = i; 
		                switch(fileName) {
		                case 0: imageNumber=0;
		                break;
		                case 1: imageNumber=1;
		                break;
		                case 2 : imageNumber=2;
		                break;
		                case 3 : imageNumber=3;
		                break;
		                case 4 : imageNumber=4;
		                break;
		                case 5 : imageNumber=5;
		                break;
		                }
		                NumberElement numberElement = new NumberElement(match.getX(), match.getY(), imageNumber); 
		                numberElements.add(numberElement);
		            }
			}
			//System.out.println(numberElements);
		        } catch (FindFailed e) {
		            // Hier könnten Sie eine Fehlermeldung ausgeben oder andere Fehlerbehandlungen durchführen.
		            //System.out.println("Das Muster wurde nicht auf dem Bildschirm gefunden.");
		            e.printStackTrace();
		        }
		

		        //System.out.println("Nach Catch");
		scannedImageOutput(screenImage);
		if(numberElements.size()<SIZE*2) {
			throw new IOException("Error detecting Numbers. If this keeps Occuring send markedScreenshot to developer (it get's created in the Folder of the Solver)");
		}
	sortPicturesToArray();
	return playingField;
		    }
	private static void sortPicturesToArray() {
		int indexLowestX=getLowestXindex();
		indexFirstNumberYAxis= getTopLeftIndex(indexLowestX);
		currentIndex = indexFirstNumberYAxis;
		numberElements.get(indexFirstNumberYAxis).setxPosInNumberHint(0);
		numberElements.get(indexFirstNumberYAxis).setyPosInNumberHint(1);
		numberElements.get(indexFirstNumberYAxis).assigned=true;
		addToPlayingField(numberElements.get(indexFirstNumberYAxis));
		
		int xPositionFirstNumberHintY = numberElements.get(indexFirstNumberYAxis).getxPosInNumberHint();
		int yPositionFirstNumberHintY = numberElements.get(indexFirstNumberYAxis).getyPosInNumberHint();
		
		
		assignOtherElements();
		
			}
	private static void scannedImageOutput(BufferedImage screenImage) {
		Graphics2D g2d = screenImage.createGraphics();

		// Setzen Sie die Eigenschaften für das Zeichnen
		g2d.setColor(Color.RED); // Farbe der Box
		g2d.setStroke(new BasicStroke(2)); // Dicke der Box

		// Schleife durch alle Matches und zeichnen Sie eine Box um jedes
		for (NumberElement numberElement : numberElements) {
		    // Annahme, dass NumberElement getX, getY Methoden hat und die Breite und Höhe konstant sind
		    g2d.drawRect(numberElement.xPosOnScreen, numberElement.yPosOnScreen, 15, 20); // Die Breite und Höhe der Box anpassen
		    // Optional: Beschriftung hinzufügen
		    g2d.drawString(String.valueOf(String.valueOf(numberElement.getNumber())), numberElement.xPosOnScreen+2, numberElement.yPosOnScreen + 14);
		}

		g2d.dispose();

		try {
		    // Speichern des bearbeiteten Screenshots
		    ImageIO.write(screenImage, "PNG", new File("markedScreen.png"));
		} catch (Exception e) {
		    e.printStackTrace();
		}
	}

	private static void assignOtherElements() {
		
		checkIfOtherNumberOnLineYAxisAndAssign();
		checkIfOtherNumberUnderLineYAxisAndAssign();
		
		int indexOfFirstXAxisElement = getFirstXAxisIndex();
		numberElements.get(indexOfFirstXAxisElement).setxPosInNumberHint(1);
		numberElements.get(indexOfFirstXAxisElement).setyPosInNumberHint(0);
		numberElements.get(indexOfFirstXAxisElement).assigned=true;
		addToPlayingField(numberElements.get(indexOfFirstXAxisElement));
		//System.out.println();
		//System.out.println("Erste in Y: "+ numberElements.get(indexFirstNumberYAxis));
		
		//System.out.println("First in X: "+ numberElements.get(indexOfFirstXAxisElement));
		
		checkIfOtherNumberUnderLineXAxisAndAssign();
	    checkIfOtherNumberRightOfLineXAxisAndAssign();
		
	}
	
	private static void checkIfOtherNumberRightOfLineXAxisAndAssign() {
		for (int i=0;i<numberElements.size();i++) {
			if (numberElements.get(i).yPosOnScreen < numberElements.get(currentIndex).yPosOnScreen+50 && numberElements.get(i).xPosOnScreen>numberElements.get(currentIndex).xPosOnScreen+15 &&
					numberElements.get(i).xPosOnScreen < numberElements.get(currentIndex).xPosOnScreen+distanceBetweenNextLineXMax && numberElements.get(i).yPosOnScreen==getLowestInYInLine()){
//				currentIndex= i;
//				checkIfOtherNumberOverLineXAxisForSecond();
				assignToRightNumberHintCords(i);
			}
		}	
	}
	private static int getLowestInYInLine() {
		int ySmallest= numberElements.get(currentIndex).yPosOnScreen+20;
		for(int i=0;i<numberElements.size();i++) {
			if(numberElements.get(i).yPosOnScreen< ySmallest && numberElements.get(i).xPosOnScreen> numberElements.get(currentIndex).xPosOnScreen+15 && 
					numberElements.get(i).xPosOnScreen< numberElements.get(currentIndex).xPosOnScreen+distanceBetweenNextLineXMax) {
				ySmallest= numberElements.get(i).yPosOnScreen;
			}
		}
		
		return ySmallest;
	}
	private static void checkIfOtherNumberUnderLineXAxisAndAssign() {
		for (int i=0;i<numberElements.size();i++) {
			if(numberElements.get(i).xPosOnScreen > numberElements.get(currentIndex).xPosOnScreen-10 && numberElements.get(i).xPosOnScreen < numberElements.get(currentIndex).xPosOnScreen+10 &&
					numberElements.get(i).yPosOnScreen > numberElements.get(currentIndex).yPosOnScreen && numberElements.get(i).yPosOnScreen < numberElements.get(currentIndex).yPosOnScreen+distanceBetweenNextNumberMaxX) {
				//System.out.println("Ist Nachbar: " +numberElements.get(i));
				assignToSameNumberHintCords(i);
				checkIfOtherNumberUnderLineXAxisAndAssign();
			}
		}
		// TODO Auto-generated method stub
		
	}
	private static int getFirstXAxisIndex() {
		int i=0;
		for(i=0;i<numberElements.size();i++) {
			if(numberElements.get(i).xPosOnScreen< numberElements.get(indexFirstNumberYAxis).xPosOnScreen +240  && 
					numberElements.get(i).yPosOnScreen < numberElements.get(indexFirstNumberYAxis).yPosOnScreen-20) {
				currentIndex=i;
				
				////System.out.println("HALLO das ist die erste Zahl"+numberElements.get(i));
				checkIfOtherNumberOverLineXAxisForFirst();
			}

		}
		return currentIndex;
	}
	
	private static void assignToRightNumberHintCords(int IndexNumberElementToAdd) {
		int x=numberElements.get(currentIndex).getxPosInNumberHint()+1;
		int y=numberElements.get(currentIndex).getyPosInNumberHint();
		numberElements.get(IndexNumberElementToAdd).setxPosInNumberHint(x);
		numberElements.get(IndexNumberElementToAdd).setyPosInNumberHint(y);
		numberElements.get(IndexNumberElementToAdd).assigned=true;
		addToPlayingField(numberElements.get(IndexNumberElementToAdd));
		currentIndex=IndexNumberElementToAdd;
		//System.out.println(numberElements.get(IndexNumberElementToAdd));
		checkIfOtherNumberUnderLineXAxisAndAssign();
		checkIfOtherNumberRightOfLineXAxisAndAssign();
		
		
	}
	private static void checkIfOtherNumberOverLineXAxisForFirst() {
		for(int j=0;j<numberElements.size();j++) {
			if (numberElements.get(j).xPosOnScreen< numberElements.get(currentIndex).xPosOnScreen+10&&numberElements.get(j).xPosOnScreen> numberElements.get(currentIndex).xPosOnScreen-10&&
					numberElements.get(j).yPosOnScreen<numberElements.get(currentIndex).yPosOnScreen) {
				currentIndex=j;
				checkIfOtherNumberOverLineXAxisForFirst();
				//System.out.println("HIIIIII");
			}
		}	
			}	
	private static void checkIfOtherNumberUnderLineYAxisAndAssign() {
		for(int i=0; i<numberElements.size();i++) {
			if(numberElements.get(i).yPosOnScreen > numberElements.get(currentIndex).yPosOnScreen+distanceBetweenNextLineYMin &&
					numberElements.get(i).yPosOnScreen < numberElements.get(currentIndex).yPosOnScreen+distanceBetweenNextLineYMax) {
//				//System.out.println("Hier kommt jeder unter der Ersten X: " + numberElements.get(i));
				int indexOfFurthestLeftNumberOfLine= checkIfOtherNumberOnLeftSideYAxis(i);
				assignToUnderNumberHintCords(indexOfFurthestLeftNumberOfLine);
			}
		}
		
		
	}
	private static int checkIfOtherNumberOnLeftSideYAxis(int indexOfElementToCheck) {
//		int xSmallest= numberElements.get(currentIndex).xPosOnScreen+20;
		int indexOfFurthestLeftNumberOfLine= indexOfElementToCheck;
		for(int i=0;i<numberElements.size();i++) {
			if(numberElements.get(i).xPosOnScreen< numberElements.get(indexOfElementToCheck).xPosOnScreen && numberElements.get(i).yPosOnScreen< numberElements.get(indexOfElementToCheck).yPosOnScreen+10
					&& numberElements.get(i).yPosOnScreen> numberElements.get(indexOfElementToCheck).yPosOnScreen-10) {
				indexOfFurthestLeftNumberOfLine= i;
				checkIfOtherNumberOnLeftSideYAxis(i);
			}
		}
		return indexOfFurthestLeftNumberOfLine;
		
	}
	private static void assignToUnderNumberHintCords(int IndexNumberElementToAdd) {
		int x=numberElements.get(currentIndex).getxPosInNumberHint();
		int y=numberElements.get(currentIndex).getyPosInNumberHint()+1;
		numberElements.get(IndexNumberElementToAdd).setxPosInNumberHint(x);
		numberElements.get(IndexNumberElementToAdd).setyPosInNumberHint(y);
		numberElements.get(IndexNumberElementToAdd).assigned=true;
		addToPlayingField(numberElements.get(IndexNumberElementToAdd));
		currentIndex=IndexNumberElementToAdd;
		//System.out.println(numberElements.get(IndexNumberElementToAdd));
		checkIfOtherNumberOnLineYAxisAndAssign();
		checkIfOtherNumberUnderLineYAxisAndAssign();
	}
	
	private static void checkIfOtherNumberOnLineYAxisAndAssign() {
		for(int i=0; i<numberElements.size();i++) {
			if(numberElements.get(i).yPosOnScreen < numberElements.get(currentIndex).yPosOnScreen+distanceBetweenNextNumberMaxY &&
					numberElements.get(i).yPosOnScreen > numberElements.get(currentIndex).yPosOnScreen-distanceBetweenNextNumberMaxY&&
					numberElements.get(i).xPosOnScreen > numberElements.get(currentIndex).xPosOnScreen && 
					numberElements.get(i).xPosOnScreen < numberElements.get(currentIndex).xPosOnScreen+60) {
				//System.out.println("ist Nachbar: "+numberElements.get(i));
				assignToSameNumberHintCords(i);
				checkIfOtherNumberOnLineYAxisAndAssign();
			}
			}
		
	}
	private static void assignToSameNumberHintCords(int IndexNumberElementToAdd) {
		
		int x=numberElements.get(currentIndex).getxPosInNumberHint();
		int y=numberElements.get(currentIndex).getyPosInNumberHint();
		numberElements.get(IndexNumberElementToAdd).setxPosInNumberHint(x);
		numberElements.get(IndexNumberElementToAdd).setyPosInNumberHint(y);
		numberElements.get(IndexNumberElementToAdd).assigned=true;
		addToPlayingField(numberElements.get(IndexNumberElementToAdd));
		currentIndex=IndexNumberElementToAdd;
	}
	
	
	private static void addToPlayingField(NumberElement numberElement) {
				int xInNumberHint = numberElement.getxPosInNumberHint();
				int yInNumberHint = numberElement.getyPosInNumberHint();
				int xInPosition	= numberElement.xPosOnScreen;
				int yInPosition	=numberElement.yPosOnScreen;
				
				int number = numberElement.getNumber();
				for (int j=0; j<playingField.getNumberHints().size();j++) {
						if (playingField.getNumberHints().get(j).getXPosition() == xInNumberHint && playingField.getNumberHints().get(j).getYPosition()== yInNumberHint) {
							playingField.getNumberHints().get(j).addNumber(number,xInPosition,yInPosition);	
							setCoordinatesOfAllBlocksToNumberHint(playingField.getNumberHints().get(j));
						}
				}
	}
		
	
	private static void setCoordinatesOfAllBlocksToNumberHint(NumberHint numberHint) {
		for(int i=0; i<playingField.getAllBlocks().size();i++) {
		if(numberHint.isInLine(playingField.getAllBlocks().get(i))&& numberHint.getXPosition()==0) {
			playingField.getAllBlocks().get(i).setyPositionCoordinates(numberHint.getyPositionOnScreen());
		}
		if(numberHint.isInLine(playingField.getAllBlocks().get(i))&& numberHint.getYPosition()==0) {
			playingField.getAllBlocks().get(i).setxPositionCoordinates(numberHint.getxPositionOnScreen());
		}
		}
		
		
	}
	//HIGHEST XVALUE ADAPTABLE
	private static int getTopLeftIndex(int indexLowestX) {
		int highestXValueAllowed =numberElements.get(indexLowestX).xPosOnScreen+100;
		////System.out.println(highestXValueAllowed);
		int indexLowestY = -1;
		int lowestY= 9999;
		for(int i=0;i<numberElements.size();i++) {
			if(lowestY > numberElements.get(i).yPosOnScreen && numberElements.get(i).xPosOnScreen< highestXValueAllowed){
			indexLowestY= i;
			lowestY = numberElements.get(i).yPosOnScreen;
			}
		}
		for(int i=0;i<numberElements.size();i++) {
		if(numberElements.get(i).xPosOnScreen< numberElements.get(indexLowestY).xPosOnScreen && numberElements.get(i).yPosOnScreen< numberElements.get(indexLowestY).yPosOnScreen+10) {
			indexLowestY=i;
		}
			
		}
		////System.out.println(numberElements.get(indexLowestX));
		//System.out.println(numberElements.get(indexLowestY));
		////System.out.println(numberElements.get(0));
		
		return indexLowestY;
	}
	private static int getLowestXindex() {
		int indexlowestX= -1;
		int lowestX = 9999;
		
			for(int j=0; j<numberElements.size();j++) {				
			if(lowestX > numberElements.get(j).xPosOnScreen) {
				indexlowestX=j;
				lowestX = numberElements.get(j).xPosOnScreen;
			}
			else {
			}		
			}		
			return indexlowestX;
			}
		
	private static void addPicturesToPattern() throws IOException {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream inputStream = classLoader.getResourceAsStream("ImagesOfDetection/NumbersEasy/0.png");
		InputStream inputStream1 = classLoader.getResourceAsStream("ImagesOfDetection/NumbersEasy/1.png");
		InputStream inputStream2 = classLoader.getResourceAsStream("ImagesOfDetection/NumbersEasy/2.png");
		InputStream inputStream3 = classLoader.getResourceAsStream("ImagesOfDetection/NumbersEasy/3.png");
		InputStream inputStream4 = classLoader.getResourceAsStream("ImagesOfDetection/NumbersEasy/4.png");
		InputStream inputStream5 = classLoader.getResourceAsStream("ImagesOfDetection/NumbersEasy/5.png");
		
		BufferedImage image0 = ImageIO.read(inputStream);
		BufferedImage image1 = ImageIO.read(inputStream1);
		BufferedImage image2 = ImageIO.read(inputStream2);
		BufferedImage image3 = ImageIO.read(inputStream3);
		BufferedImage image4 = ImageIO.read(inputStream4);
		BufferedImage image5 = ImageIO.read(inputStream5);

		Pattern pattern0 = new Pattern(image0).similar(0.9);
		Pattern pattern1 = new Pattern(image1).similar(0.9);
		Pattern pattern2 = new Pattern(image2).similar(0.9);
		Pattern pattern3 = new Pattern(image3).similar(0.9);
		Pattern pattern4 = new Pattern(image4).similar(0.9);
		Pattern pattern5 = new Pattern(image5).similar(0.9);
		allPattern.add(pattern0);
		allPattern.add(pattern1);
		allPattern.add(pattern2);
		allPattern.add(pattern3);
		allPattern.add(pattern4);
		allPattern.add(pattern5);
	}
		}
