package mainApp;

import java.util.ArrayList;
import java.util.Scanner;

public class NumberHint {
	Scanner scan= new Scanner(System.in);
	
	private int xPosition;
	private int yPosition;
	private int xPositionOnScreen;
	private int yPositionOnScreen;
	
	
	
	private ArrayList<Integer> numbers = new ArrayList<Integer>();
	
	private int possibleAmountOfRightStreaks=0;
	
	private int amountOfFreeBoxes=0;
	private int amountOfBombBoxes=0;
	
	private boolean correctAmountOfBoxes;
	private boolean allCorrect=false;
	private boolean checkedForStreak;
	
	public NumberHint(int xPosition,int yPosition,int ...numbers){
		this.xPosition = xPosition;
		this.yPosition = yPosition;
		for (int i=0;i<numbers.length;i++) {
		this.numbers.add(numbers[i]);	
		}
	}
	
	public void addAmountOfFreeBoxes() {
		if(!this.correctAmountOfBoxes)
		amountOfFreeBoxes++;
	}
	public void amountOfFreeBoxes(ArrayList<Block> allBlocks) {
		this.amountOfFreeBoxes=0;
		for (int i=0;i<allBlocks.size();i++)
		if(this.isInLine(allBlocks.get(i))&& allBlocks.get(i).isFreeBox()==true) {
			this.amountOfFreeBoxes++;
		}
	}
	public int getPossibleAmountOfRightStreaks() {
		return possibleAmountOfRightStreaks;
	}

	public void addPossibleAmountOfRightStreaks(int possibleAmountOfRightStreaks) {
		this.possibleAmountOfRightStreaks += possibleAmountOfRightStreaks;
	}
	
	public int getXPosition() {
		return xPosition;
	}
	public int getxPositionOnScreen() {
		return xPositionOnScreen;
	}

	public void setxPositionOnScreen(int xPositionOnScreen) {
		this.xPositionOnScreen = xPositionOnScreen;
	}

	public int getyPositionOnScreen() {
		return yPositionOnScreen;
	}

	public void setyPositionOnScreen(int yPositionOnScreen) {
		this.yPositionOnScreen = yPositionOnScreen;
	}

	public int getYPosition() {
		return yPosition;
	}
	public ArrayList<Integer> getNumbers() {
		return this.numbers;
	}
	public void addNumber(int newNumber,int xPosition, int yPosition) {
		getNumbers().add(newNumber);
		this.xPositionOnScreen=xPosition;
		this.yPositionOnScreen=yPosition;
		//amountOfFreeBoxes +=newNumber;
	}
	public String toString() {
		return "Position X/Y: "+xPosition+"/"+yPosition+" Zahlen: "+ numbers+" amountOfFreeBoxes: "+amountOfFreeBoxes+ "  Row REALLY correct: "+ this.allCorrect+
				"Possible Combinations: "+ this.possibleAmountOfRightStreaks;
	}
	
	public int getAddedNumbers(){
		int totalAmount=0;
		for (int i=0;i < numbers.size();i++) {
		totalAmount+=numbers.get(i);
		}
		return totalAmount;
	}
	public int getAddedNumbersAndSpaces() {
		int totalAmount=0;
		for (int i=0;i < numbers.size();i++) {
			totalAmount+=numbers.get(i);
		}
			totalAmount+= numbers.size()-1;
			
		return totalAmount;
	}
	public boolean isAllCorrect() {
		return this.allCorrect;
	}
	
	public int getAddedNumbersToIndex(int index) {
		int addedNumbersTillIndex=0;
		for (int i=0;i<=index;i++) {
			addedNumbersTillIndex += this.numbers.get(i);
		}
		addedNumbersTillIndex += index;
		return addedNumbersTillIndex;
	}
	public int getNumbersAndSpacesOnLeft(int numbersIndex) {
		int totalNumbersAndSpacesOnLeft=0;
		for(int i= 0; i<numbersIndex; i++) {
			totalNumbersAndSpacesOnLeft+=this.numbers.get(i)+1;
		}
		return totalNumbersAndSpacesOnLeft;
	}
	public int getNumbersAndSpacesOnRight(int numbersIndex) {
		int totalNumbersAndSpacesOnRight=0;
		for(int i= numbersIndex+1; i<this.numbers.size(); i++) {
			totalNumbersAndSpacesOnRight+=this.numbers.get(i)+1;
		}
		return totalNumbersAndSpacesOnRight;
	}
	
	
	
	public int getAmountOfFreeBoxes() {
		return amountOfFreeBoxes;
	}
	
	public boolean isInLine(Block block) {
		if (block.getXPosition()==this.xPosition || block.getYPosition()==this.yPosition)
		return true;
		else
			return false;
	}
	public boolean isInXLine(Block block) {
		if (block.getXPosition()==this.xPosition)
			return true;
		else
			return false;
	}
	public boolean isInYLine(Block block) {
		if ( block.getYPosition()==this.yPosition)
			return true;
		else
			return false;
	}
	public void setCorrectNumberOfBoxesInLine(boolean bool) {
		if (bool==true) {
			//scan.nextLine();
		}
		this.correctAmountOfBoxes=bool;
	}
	public boolean isCorrectNumberOfBoxes() {
		return this.correctAmountOfBoxes;
	}

	public void getBoxesInLine() {
		
//		retz
	}
	public void resetAmountOfFreeBoxes() {
		if (!this.isCorrectNumberOfBoxes()) {
		this.amountOfBombBoxes=0;
		}
	}
	public void setAllCorrect(boolean bool) {
		this.allCorrect=bool;
	}
	
	//Alles komplett Korrekt
	public boolean correctStreakOfFreeBlocks(ArrayList<Block> allBlocks){
		if(!allCorrect&&isCorrectNumberOfBoxes()) {
			
			
			////System.out.println(this);

		int correctStreaks=0;
		int realStreak=0;
	if(this.getYPosition()==0) {
		for(Block block: allBlocks) {
			if(this.isInLine(block)){
				block.setVerticalStreakTested(false);
			}
		}
//		//System.out.println("X/Y: "+this.getXPosition()+"/"+ this.getYPosition()+this.getNumbers());
		boolean inStreak= false;
		for(int j=0;j<this.numbers.size();j++) {
			realStreak=0;
			////System.out.println(this.numbers.size());
			for (int i=0;i<allBlocks.size();i++) {
				if (this.isInXLine(allBlocks.get(i))&& !allBlocks.get(i).isVerticalStreakTested()) {
				// //System.out.println(allBlocks.get(i));
				int wantedStreak =this.getNumbers().get(j);
				int counter= 0;
				while (correctStreaks<=j && !allBlocks.get(i).isVerticalStreakTested()) {
		//			//System.out.println(i);
				
				int yPosOfAdjacentBox = allBlocks.get(i).getYPosition()+1;
				int xPosOfAdjacentBox = allBlocks.get(i).getXPosition();
				//o = index of Adjacent Block
					int o=getIndexOfAdjacentBox(xPosOfAdjacentBox,yPosOfAdjacentBox,allBlocks);
					if(o==-1 && allBlocks.get(i).isFreeBox()) {
						realStreak++;
						allBlocks.get(i).setVerticalStreakTested(true);
						if (realStreak==wantedStreak) {
							correctStreaks++;
						}
						else
						{
							return false;
						}
					}

					if(o==-1 && !allBlocks.get(i).isFreeBox()) {
						allBlocks.get(i).setVerticalStreakTested(true);
						if (inStreak) {
							inStreak=false;
							if(realStreak==wantedStreak && !inStreak) {
								correctStreaks++;
								inStreak=false;
								}
							else
								return false;
							
						}
					}
					
					if(o!=-1) {
					if(allBlocks.get(i).isFreeBox()){
						allBlocks.get(i).setVerticalStreakTested(true);
					if(inStreak) {
						realStreak++;
					}
					else {
					realStreak++;
					}
						inStreak=true;
					}
					
					if(!allBlocks.get(i).isFreeBox()) {
						allBlocks.get(i).setVerticalStreakTested(true);
						
						if(inStreak) {
							inStreak=false;
							if(realStreak==wantedStreak && !inStreak) {
								correctStreaks++;
							}
							else 
								return false;
						}
						allBlocks.get(i).setVerticalStreakTested(true);
						//i=o;
						inStreak=false;
					}
				}
					
//					if(inStreak) {
//					counter++;
//					}
									
					if( !(o == -1)) {
					i=o;
					}
				}
				}
			}
		}
	}
	if(this.getXPosition() == 0) {
		for(Block block: allBlocks) {
			if(this.isInLine(block)){
				block.setHorizontalStreakTested(false);
			}
		}
		//System.out.println("X/Y: "+this.getXPosition()+"/"+ this.getYPosition()+this.getNumbers());
	    boolean inStreak = false;
	    for(int j = 0; j < this.numbers.size(); j++) {
	    	////System.out.println(this);
	        realStreak = 0;
	        for (int i = 0; i < allBlocks.size(); i++) {
	            if (this.isInYLine(allBlocks.get(i)) && !allBlocks.get(i).isHorizontalStreakTested()) {
	                int wantedStreak = this.getNumbers().get(j);
	                int counter = 0;
	                while (correctStreaks <= j && !allBlocks.get(i).isHorizontalStreakTested()) {
	                    int xPosOfAdjacentBox = allBlocks.get(i).getXPosition() + 1;
	                    int yPosOfAdjacentBox = allBlocks.get(i).getYPosition();
	                    int o = getIndexOfAdjacentBox(xPosOfAdjacentBox, yPosOfAdjacentBox, allBlocks);
	                    
	                    if (o == -1 && allBlocks.get(i).isFreeBox()) {
	                        realStreak++;
	                        allBlocks.get(i).setHorizontalStreakTested(true);
	                        if (realStreak == wantedStreak) {
	                            correctStreaks++;
	                        } else {
	                            return false;
	                        }
	                    }

	                    if (o == -1 && !allBlocks.get(i).isFreeBox()) {
	                        allBlocks.get(i).setHorizontalStreakTested(true);
	                        if (inStreak) {
	                            if (realStreak == wantedStreak) {
	                                correctStreaks++;
	                                inStreak = false;
	                            } else {
	                                return false;
	                            }
	                        }
	                    }

	                    if (o != -1) {
	                        if (allBlocks.get(i).isFreeBox()) {
	                            allBlocks.get(i).setHorizontalStreakTested(true);
	                            realStreak++;
	                            inStreak = true;
	                        }

	                        if (!allBlocks.get(i).isFreeBox()) {
	                            allBlocks.get(i).setHorizontalStreakTested(true);
	                            if (inStreak) {
	                                inStreak = false;
	                                if (realStreak == wantedStreak) {
	                                    correctStreaks++;
	                                } else {
	                                    return false;
	                                }
	                            }
	                        }
	                    }

	                    if (inStreak) {
	                        counter++;
	                    }

	                    if (!(o == -1)) {
	                        i = o;
	                    }
	                }
	            }
	        }
	    }
	}

		if(correctStreaks==this.numbers.size()&&isCorrectNumberOfBoxes()) {
			
			for (int i=0; i<allBlocks.size();i++)
			if(this.isInLine(allBlocks.get(i))) {
				if(allBlocks.get(i).getXPosition()==this.xPosition) {
				allBlocks.get(i).setVerticalStreakConfirmed(true);
				}
				else
				allBlocks.get(i).setHorizontalStreakConfirmed(true);
//				//System.out.println("Hallo");
			}
			return true;
//			this.allCorrect=true;
		}
		
		else {
			this.allCorrect=false;
		}
	}
		if(allCorrect && isCorrectNumberOfBoxes()) {
		return true;
		}
		else return false;
	}
	
	public boolean correctStreakOfFreeBlocksInBruteForce(ArrayList<Block> allBlocks){
		if(!allCorrect&&isCorrectNumberOfBoxes()) {
			
			
			////System.out.println(this);

		int correctStreaks=0;
		int realStreak=0;
	if(this.getYPosition()==0) {
		for(Block block: allBlocks) {
			if(this.isInLine(block)){
				block.setVerticalStreakTested(false);
			}
		}
//		//System.out.println("X/Y: "+this.getXPosition()+"/"+ this.getYPosition()+this.getNumbers());
		boolean inStreak= false;
		for(int j=0;j<this.numbers.size();j++) {
			realStreak=0;
			////System.out.println(this.numbers.size());
			for (int i=0;i<allBlocks.size();i++) {
				if (this.isInXLine(allBlocks.get(i))&& !allBlocks.get(i).isVerticalStreakTested()) {
				// //System.out.println(allBlocks.get(i));
				int wantedStreak =this.getNumbers().get(j);
				int counter= 0;
				while (correctStreaks<=j && !allBlocks.get(i).isVerticalStreakTested()) {
		//			//System.out.println(i);
				
				int yPosOfAdjacentBox = allBlocks.get(i).getYPosition()+1;
				int xPosOfAdjacentBox = allBlocks.get(i).getXPosition();
				//o = index of Adjacent Block
					int o=getIndexOfAdjacentBox(xPosOfAdjacentBox,yPosOfAdjacentBox,allBlocks);
					if(o==-1 && allBlocks.get(i).isFreeBox()) {
						realStreak++;
						allBlocks.get(i).setVerticalStreakTested(true);
						if (realStreak==wantedStreak) {
							correctStreaks++;
						}
						else
						{
							return false;
						}
					}

					if(o==-1 && !allBlocks.get(i).isFreeBox()) {
						allBlocks.get(i).setVerticalStreakTested(true);
						if (inStreak) {
							inStreak=false;
							if(realStreak==wantedStreak && !inStreak) {
								correctStreaks++;
								inStreak=false;
								}
							else
								return false;
							
						}
					}
					
					if(o!=-1) {
					if(allBlocks.get(i).isFreeBox()){
						allBlocks.get(i).setVerticalStreakTested(true);
					if(inStreak) {
						realStreak++;
					}
					else {
					realStreak++;
					}
						inStreak=true;
					}
					
					if(!allBlocks.get(i).isFreeBox()) {
						allBlocks.get(i).setVerticalStreakTested(true);
						
						if(inStreak) {
							inStreak=false;
							if(realStreak==wantedStreak && !inStreak) {
								correctStreaks++;
							}
							else 
								return false;
						}
						allBlocks.get(i).setVerticalStreakTested(true);
						//i=o;
						inStreak=false;
					}
				}
					
//					if(inStreak) {
//					counter++;
//					}
									
					if( !(o == -1)) {
					i=o;
					}
				}
				}
			}
		}
	}
	if(this.getXPosition() == 0) {
		for(Block block: allBlocks) {
			if(this.isInLine(block)){
				block.setHorizontalStreakTested(false);
			}
		}
		//System.out.println("X/Y: "+this.getXPosition()+"/"+ this.getYPosition()+this.getNumbers());
	    boolean inStreak = false;
	    for(int j = 0; j < this.numbers.size(); j++) {
	    	////System.out.println(this);
	        realStreak = 0;
	        for (int i = 0; i < allBlocks.size(); i++) {
	            if (this.isInYLine(allBlocks.get(i)) && !allBlocks.get(i).isHorizontalStreakTested()) {
	                int wantedStreak = this.getNumbers().get(j);
	                int counter = 0;
	                while (correctStreaks <= j && !allBlocks.get(i).isHorizontalStreakTested()) {
	                    int xPosOfAdjacentBox = allBlocks.get(i).getXPosition() + 1;
	                    int yPosOfAdjacentBox = allBlocks.get(i).getYPosition();
	                    int o = getIndexOfAdjacentBox(xPosOfAdjacentBox, yPosOfAdjacentBox, allBlocks);
	                    
	                    if (o == -1 && allBlocks.get(i).isFreeBox()) {
	                        realStreak++;
	                        allBlocks.get(i).setHorizontalStreakTested(true);
	                        if (realStreak == wantedStreak) {
	                            correctStreaks++;
	                        } else {
	                            return false;
	                        }
	                    }

	                    if (o == -1 && !allBlocks.get(i).isFreeBox()) {
	                        allBlocks.get(i).setHorizontalStreakTested(true);
	                        if (inStreak) {
	                            if (realStreak == wantedStreak) {
	                                correctStreaks++;
	                                inStreak = false;
	                            } else {
	                                return false;
	                            }
	                        }
	                    }

	                    if (o != -1) {
	                        if (allBlocks.get(i).isFreeBox()) {
	                            allBlocks.get(i).setHorizontalStreakTested(true);
	                            realStreak++;
	                            inStreak = true;
	                        }

	                        if (!allBlocks.get(i).isFreeBox()) {
	                            allBlocks.get(i).setHorizontalStreakTested(true);
	                            if (inStreak) {
	                                inStreak = false;
	                                if (realStreak == wantedStreak) {
	                                    correctStreaks++;
	                                } else {
	                                    return false;
	                                }
	                            }
	                        }
	                    }

	                    if (inStreak) {
	                        counter++;
	                    }

	                    if (!(o == -1)) {
	                        i = o;
	                    }
	                }
	            }
	        }
	    }
	}

		if(correctStreaks==this.numbers.size()&&isCorrectNumberOfBoxes()) {
			
			for (int i=0; i<allBlocks.size();i++)
			if(this.isInLine(allBlocks.get(i))) {
				if(allBlocks.get(i).getXPosition()==this.xPosition) {
				allBlocks.get(i).setVerticalStreakConfirmed(true);
				}
				else
				allBlocks.get(i).setHorizontalStreakConfirmed(true);
//				//System.out.println("Hallo");
			}
			return true;
//			this.allCorrect=true;
		}
		
		else {
			this.allCorrect=false;
		}
	}
		if(allCorrect && isCorrectNumberOfBoxes()) {
		return true;
		}
		else return false;
	}
	
	
	private int getIndexOfAdjacentBox(int xPosOfAdjacentBox, int yPosOfAdjacentBox, ArrayList<Block> allBlocks) {
		for(int i=0;i<allBlocks.size();i++) {
			if(allBlocks.get(i).getXPosition()==xPosOfAdjacentBox && allBlocks.get(i).getYPosition()==yPosOfAdjacentBox) {
				////System.out.println(allBlocks.get(i));
				
				return i;
			}
		}
		return -1;
	}
	 public NumberHint copy() {
	        // Neue Instanz mit denselben xPosition und yPosition Werten
	        NumberHint copiedHint = new NumberHint(this.xPosition, this.yPosition);
	        // Kopiere die Zahlen in die neue Instanz
	        for (Integer number : this.numbers) {
	            copiedHint.numbers.add(number);
	        }
	        
	        // Kopiere die Zustände der Instanzvariablen
	        copiedHint.amountOfFreeBoxes = this.amountOfFreeBoxes;
	        copiedHint.amountOfBombBoxes = this.amountOfBombBoxes;
	        copiedHint.correctAmountOfBoxes = this.correctAmountOfBoxes;
	        copiedHint.allCorrect = this.allCorrect;
	        copiedHint.checkedForStreak = this.checkedForStreak;
	        copiedHint.yPositionOnScreen= this.yPositionOnScreen;
	        copiedHint.xPositionOnScreen= this.xPositionOnScreen;

	        return copiedHint;
	    }

	
}
